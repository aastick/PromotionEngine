﻿using PromotionEngine.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    class Program
    {
        Product p = new Product();
        Order o = new Order();
        Promotion po = new Promotion();
        static void Main(string[] args)
        {
            Program pr = new Program();
           Console.WriteLine(pr.ApplyPromotionGetTotalPrice());
            Console.ReadLine();

        }

        public  int ApplyPromotionGetTotalPrice()
        {
            int totalPrice = 0;
           var orderPrice= o.GetOrderDetails();

            foreach(KeyValuePair<string, int> entry in orderPrice)
            {
                var promotionOffer = po.GetPromtion();
                var productList = p.GetProductPrice();
                
               var filteredPromotion= promotionOffer.Where(x => x.Key == entry.Key).FirstOrDefault();

                if (filteredPromotion.Key==null)
                {
                   var combinedPromo=  promotionOffer.Where(x => x.Key.Contains(entry.Key)).FirstOrDefault();
                   var index= combinedPromo.Key.IndexOf(entry.Key);
                   var comboOrd= orderPrice.Where(x=>x.Key.Contains(combinedPromo.Key[index + 1])).FirstOrDefault();

                    if (comboOrd.Key != null && index==1)
                    {
                        totalPrice += filteredPromotion.Value[0];
                    }

                    
                   

                }
                else
                {
                    var filteredProductPrice = productList.Where(x => x.Key == entry.Key).FirstOrDefault();
                    if (entry.Value >= filteredPromotion.Value[0])
                    {
                        int orderQty = entry.Value;
                        if (orderQty % filteredPromotion.Value[0] == 0)
                        {
                            int afterDiscountPrice = (orderQty / filteredPromotion.Value[0]) * filteredPromotion.Value[1];
                            totalPrice += afterDiscountPrice;
                        }
                        else
                        {
                            int afterDiscountPrice = ((orderQty / filteredPromotion.Value[0]) * filteredPromotion.Value[1]) + (filteredProductPrice.Value * (orderQty % filteredPromotion.Value[0]));
                            totalPrice += afterDiscountPrice;
                        }

                    }
                }

               
            }

            return totalPrice;
        }
    }
}
