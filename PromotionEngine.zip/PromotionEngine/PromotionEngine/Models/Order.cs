﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine.Models
{
    class Order
    {
        public Dictionary<string, int> GetOrderDetails()
        {
            Dictionary<string, int> dtOrderQty = new Dictionary<string, int>();

            //Based on Scneario 2;

            dtOrderQty.Add("A", 5);
            dtOrderQty.Add("B", 5);
            dtOrderQty.Add("C", 1);
            //dtOrderQty.Add("D", 15);

            return dtOrderQty;
        }
    }
}
