﻿using PromotionEngine.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine.Models
{
    class Product:IProduct
    {
      public  Dictionary<string, int> GetProductPrice()
        {
            Dictionary<string, int> dtProduct = new Dictionary<string, int>();

            dtProduct.Add("A", 50);
            dtProduct.Add("B", 30);
            dtProduct.Add("C", 20);
            dtProduct.Add("D", 15);

            return dtProduct;
        }
    }
}
