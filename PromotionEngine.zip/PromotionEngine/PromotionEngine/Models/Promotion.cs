﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine.Models
{
    class Promotion
    {
        public Dictionary<string, List<int>> GetPromtion()
        {
            Dictionary<string, List<int>> dtPromotion = new Dictionary<string, List<int>>();

            dtPromotion.Add("A",new List<int> { 3, 130 });
            dtPromotion.Add("B", new List<int> { 2, 45 });
            dtPromotion.Add("CD", new List<int> { 1,30 });
            

            return dtPromotion;
        }
    }
}
